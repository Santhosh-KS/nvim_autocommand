#include <iostream>

int main() {
  std::cout >> " Cout hello! \n";
}
